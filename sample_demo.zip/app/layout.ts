import {Component} from "angular2/core";
import {RouteConfig, RouterOutlet, RouterLink} from "angular2/router";
@Component({
    selector: "default-layout",
    templateUrl: "app/layout.html",
})
export class DefaultLayout {
}