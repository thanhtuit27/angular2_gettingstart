﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace WebApi.Controllers
{
    [RoutePrefix("api/users")]
    public class UsersController : ApiController
    {
        static IList<User> users = GetFakeUsers();

        [HttpGet]
        public IList<User> GetUsers()
        {
            return users;
        }

        [HttpGet]
        [Route("{id}")]
        public User GetUser(int id)
        {
            return users.Where(user => user.Id == id).FirstOrDefault();
        }
        [HttpPost]
        public void CreateUser(User user)
        {
            if (user.Id <= 0)
            {
                user.Id = users.Count + 1;
                users.Add(user);
            }
            else {
                User currentUser = GetUser(user.Id);
                currentUser.Name = user.Name;
                currentUser.Gender = user.Gender;
            }
            
        }

        private static IList<User> GetFakeUsers()
        {
            return new List<User>() {
                new User(1, "User 1","male"),
                new User(1, "User 2","female")
            };
        }
    }
    public class User
    {
        public User(int id, string name, string gender)
        {
            this.Id = id;
            this.Name = name;
            this.Gender = gender;
        }
        public int Id { get; set; }
        public string Name { get; set; }
        public string Gender { get; set; }
    }
}
