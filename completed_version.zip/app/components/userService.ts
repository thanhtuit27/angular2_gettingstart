import {Observable} from 'rxjs/Observable';
import 'rxjs/Rx';
import {Injectable} from "angular2/core";
import {Http, Headers} from "angular2/http";
@Injectable()
export class UserService{
    private http: Http;
    private baseUrl: string="http://localhost:10849/api/";
    constructor(http: Http){
        this.http =  http;
    }
    public save(user: any){
        let headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append("Accept", "application/json");
        let url=this.baseUrl+ "users";
        let dataInString: string = JSON.stringify(user);
        return this.http.post(url, dataInString, {headers: headers})
        .toPromise();
    }
    public getUser(userId: string): any{
        let headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append("Accept", "application/json");
        let url=this.baseUrl+ "users/"+ userId;
        return this.http.get(url, {headers: headers})
        .toPromise()
        .then((response: any) => this.handleResponse(response));
    }
    public getUsers():any{
        let headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append("Accept", "application/json");
        let url=this.baseUrl+ "users";
        return this.http.get(url, {headers: headers})
        .toPromise()
        .then((response: any) => this.handleResponse(response));
    }
    private handleResponse(response: any){
        console.log(response);
        return  response.json();
    }
}
