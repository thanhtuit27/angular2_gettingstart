import {Component} from "angular2/core";
import {RouteParams, Router} from "angular2/router";
import {UserService} from "./userService";

@Component({
    selector: "users",
    templateUrl: "app/components/addUser.html"
})
export class AddUser {
    private actionType: ActionType = ActionType.AddNew;
    private user: any = {};
    private userService: UserService;
    private router: Router;
    constructor(params: RouteParams, userService: UserService, router: Router) {
        let self: AddUser = this;
        
        self.router = router;
        self.userService = userService;
        
        if (!!params.get("id")) {
            this.actionType = ActionType.Edit;
            userService.getUser(params.get("id")).then(function (userDetail: any) {
                self.user = userDetail;
            });
        }
    }
    public onSaveClicked() {
        let self: AddUser = this;
        self.userService.save(self.user).then(function () {
            self.router.navigate(["Users"]);
        });
    }
}
enum ActionType {
    AddNew,
    Edit
};