import {Component} from "angular2/core";
import {ROUTER_DIRECTIVES, Router} from "angular2/router";
import {UserView} from "./userView";
import {UserService} from "./userService";
import {UserDetail} from "./userDetail"
@Component({
    selector: "users",
    templateUrl: "app/components/users.html",
    directives: [ROUTER_DIRECTIVES, UserView, UserDetail]
})
export class Users {
    private router: Router;
    public model: any = [];
    public selectedUser: UserModel = null;
    constructor(router: Router, userService: UserService) {
        this.router= router;
        userService.getUsers().then((users: any) =>this.model = users);
        this.selectedUser=this.model[0];
    }
    public onUserClicked(user: any ) {
        console.log(user);
        this.selectedUser = user;
    }
    public onNameChanged(name: string){
        this.selectedUser.name = name;
    }
    public onEditClicked(user: any){
        this.router.navigate(["Edit User", {id: user.id}]);
    }
    public onQuickViewClicked(user: any){
        this.selectedUser = user;
    }
}
