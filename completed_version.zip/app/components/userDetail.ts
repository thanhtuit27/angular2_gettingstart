import {Component} from "angular2/core";
@Component({
    selector:"user-detail",
    templateUrl:"app/components/userDetail.html"
})
export class UserDetail{}