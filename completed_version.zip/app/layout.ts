import {Component} from "angular2/core";
import {RouteConfig, RouterOutlet, RouterLink} from "angular2/router";
import {Users} from "./components/users";
import {AddUser} from "./components/addUser";
@Component({
    selector: "default-layout",
    templateUrl: "app/layout.html",
    directives: [RouterOutlet, RouterLink]
})
@RouteConfig([
    { path: "/users", name: "Users", component: Users, useAsDefault: true },
    { path: "/adduser", name: "Add User", component: AddUser },
    { path: "/editUser/:id", name: "Edit User", component: AddUser }
])
export class DefaultLayout {
}